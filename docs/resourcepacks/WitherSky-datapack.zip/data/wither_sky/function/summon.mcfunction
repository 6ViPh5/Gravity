# Fase de invocacion (Wither con Invul > 0): se abre una grieta en el cielo
scoreboard players set #phase ws.state 1
customskyboxes set @a rift wither_void.png type=crack radius=40 posY=55 layer=1 anim_in=rift_awaken anim_in_time=120 anim_out=rift_wither anim_out_time=100
customskyboxes animate @a rift tremor 200 shake=1 glow=1 layer=1
