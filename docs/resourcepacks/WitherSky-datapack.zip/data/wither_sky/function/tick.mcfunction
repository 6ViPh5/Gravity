# 1) leer estado del Wither
execute store result score #count ws.state if entity @e[type=minecraft:wither]
scoreboard players set #invul ws.state 0
execute if score #count ws.state matches 1.. store result score #invul ws.state run data get entity @e[type=minecraft:wither,limit=1] Invul

# 2) transiciones (solo cuando cambia el estado, para no spamear comandos)
execute if score #count ws.state matches 1.. if score #phase ws.state matches 0 run function wither_sky:start
execute if score #phase ws.state matches 1 if score #invul ws.state matches ..0 if score #forced ws.state matches 0 run function wither_sky:combat
execute if score #count ws.state matches 0 if score #forced ws.state matches 0 unless score #phase ws.state matches 0 run function wither_sky:end

# 3) cada rayo nuevo mientras el evento esta activo = destello en el cielo
execute unless score #phase ws.state matches 0 as @e[type=minecraft:lightning_bolt,tag=!ws.seen] run function wither_sky:strike
