# PRUEBAS: /function wither_sky:force_start (no necesita Wither)
scoreboard players set #forced ws.state 1
scoreboard players set #invul ws.state 1
function wither_sky:start
