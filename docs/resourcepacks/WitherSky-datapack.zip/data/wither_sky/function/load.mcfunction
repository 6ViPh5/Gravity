# Estado: #phase 0 = inactivo, 1 = invocando (Invul > 0), 2 = combate
# #forced 1 = activado a mano con force_start (no termina solo)
scoreboard objectives add ws.state dummy
execute unless score #phase ws.state matches 0..2 run scoreboard players set #phase ws.state 0
execute unless score #forced ws.state matches 0..1 run scoreboard players set #forced ws.state 0
scoreboard players set #count ws.state 0
scoreboard players set #invul ws.state 0
