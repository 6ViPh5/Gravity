# Ejecutada por cada rayo nuevo (as @e[type=lightning_bolt])
tag @s add ws.seen
customskyboxes animate @a sky flash 10 color=#cfd8ff strength=1.2
