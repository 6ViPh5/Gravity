# El Wither ya no existe: volver al cielo normal (cada clear reproduce su anim_out)
scoreboard players set #phase ws.state 0
scoreboard players set #forced ws.state 0
customskyboxes animate @a stop
customskyboxes clear @a rift
customskyboxes clear @a sky
customskyboxes clear @a clouds
customskyboxes clear @a stars
customskyboxes clear @a sun
customskyboxes clear @a moon
