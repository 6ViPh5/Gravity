# PRUEBAS: simula el fin de la invocacion
function wither_sky:combat
