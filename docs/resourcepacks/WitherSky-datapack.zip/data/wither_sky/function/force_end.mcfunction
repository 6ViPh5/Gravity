# PRUEBAS: /function wither_sky:force_end
function wither_sky:end
