# Se detecta un Wither: activar cielo de tormenta
scoreboard players set #phase ws.state 2
execute if score #invul ws.state matches 1.. run function wither_sky:summon

customskyboxes set @a sky wither_storm.png opacity=1 anim_in=smoke_in anim_in_time=100 anim_out=smoke_out anim_out_time=160
customskyboxes set @a clouds wither_clouds.png opacity=0.95 speed=2.5 fadein=100 fadeout=140
customskyboxes set @a stars #8a1224 fadein=100 fadeout=140
customskyboxes set @a sun vanilla opacity=0 fadein=60 fadeout=140
customskyboxes set @a moon vanilla opacity=0.45 fadein=100 fadeout=140
