# El Wither termino de invocarse: onda de choque, la grieta se marchita y empieza el latido
scoreboard players set #phase ws.state 2
customskyboxes animate @a sky shockwave 40 color=#7a1fa2 strength=1.5
customskyboxes clear @a rift
customskyboxes animate @a sky heartbeat 100 color=#600010 strength=0.5 loop=true
