package com.gameboyaddon.item;

import com.gameboyaddon.GameboyAddon;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class GameboyItem extends Item {
    public GameboyItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) {
            GameboyAddon.clientUse.run();
        }
        return InteractionResult.CONSUME;
    }
}
