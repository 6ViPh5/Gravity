package com.gameboyaddon.client;

import com.gameboyaddon.GameboyAddon;
import com.gameboyaddon.network.GameboyPosePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public final class GameboyAddonClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        GameboyAddon.clientUse = GameboyClient::openFromItem;
        ClientPlayNetworking.registerGlobalReceiver(GameboyPosePayload.TYPE,
                (payload, context) -> GameboyClient.setPose(payload.player(), payload.playing()));
        ClientTickEvents.END_CLIENT_TICK.register(GameboyClient::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> GameboyClient.reset());
    }
}
