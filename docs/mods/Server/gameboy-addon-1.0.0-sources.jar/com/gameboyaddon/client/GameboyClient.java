package com.gameboyaddon.client;

import com.gameboyaddon.GameboyAddon;
import com.gameboyaddon.network.GameboySoundPayload;
import com.gameboyaddon.network.GameboyStatePayload;
import com.zeesea.client.ClientCompat;
import com.zeesea.client.gui.SleepScreen;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

public final class GameboyClient {
    /** Jugadores (incluido yo) que ahora mismo tienen los brazos en pose de Gameboy. */
    private static final Set<UUID> POSING = ConcurrentHashMap.newKeySet();
    private static boolean localPlaying;
    private static boolean localScreenOn;
    private static int heartbeat;

    private GameboyClient() {
    }

    public static boolean isPosing(UUID id) {
        return POSING.contains(id);
    }

    public static void setPose(UUID id, boolean on) {
        if (on) {
            POSING.add(id);
        } else {
            POSING.remove(id);
        }
    }

    public static void reset() {
        POSING.clear();
        localPlaying = false;
        localScreenOn = false;
        heartbeat = 0;
    }

    /** Clic derecho con la Gameboy: abre la pantalla del arcade (modo "preview" del mod original). */
    public static void openFromItem() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            SleepScreen.openPreview(mc);
        }
    }

    public static boolean holdsGameboy(LocalPlayer player) {
        return player.getMainHandItem().is(GameboyAddon.GAMEBOY) || player.getOffhandItem().is(GameboyAddon.GAMEBOY);
    }

    public static void tick(Minecraft mc) {
        LocalPlayer player = mc.player;
        if (player == null) {
            reset();
            return;
        }
        var screen = ClientCompat.screen(mc);
        boolean now = screen instanceof SleepScreen
                && !player.isSleeping()
                && holdsGameboy(player);
        boolean screenOn = now && ArcadeProbe.gameActive(screen);

        if (now != localPlaying || screenOn != localScreenOn) {
            localPlaying = now;
            localScreenOn = screenOn;
            heartbeat = 0;
            setPose(player.getUUID(), now);
            safeSend(new GameboyStatePayload(now, screenOn));
        } else if (now && ++heartbeat >= 40) {
            // Reafirma el estado cada 2 s por si el servidor lo soltó.
            heartbeat = 0;
            safeSend(new GameboyStatePayload(true, screenOn));
        }
    }

    /** Lo llama el mixin de Sfx cada vez que el minijuego hace un sonido. */
    public static void sendSound(int instrument, float pitch) {
        if (localPlaying) {
            safeSend(new GameboySoundPayload(instrument, pitch));
        }
    }

    private static void safeSend(net.minecraft.network.protocol.common.custom.CustomPacketPayload payload) {
        try {
            ClientPlayNetworking.send(payload);
        } catch (RuntimeException ignored) {
            // Servidor sin el addon: se juega igual, solo sin pose ni sonido compartido.
        }
    }
}
