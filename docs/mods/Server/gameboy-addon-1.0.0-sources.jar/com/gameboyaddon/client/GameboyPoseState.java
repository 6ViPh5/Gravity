package com.gameboyaddon.client;

/** Se añade a LivingEntityRenderState (vía mixin) para llevar la pose hasta el modelo. */
public interface GameboyPoseState {
    void gameboyaddon$setPosing(boolean posing);

    boolean gameboyaddon$isPosing();
}
