package com.gameboyaddon.client;

import com.gameboyaddon.GameboyAddon;
import com.zeesea.client.gui.SleepScreen;
import java.lang.reflect.Field;

/**
 * Lee (por reflexión) el estado interno de la pantalla de Arcade Dreams:
 * ¿hay un minijuego en curso o en pausa? No toca nada del mod original.
 */
final class ArcadeProbe {
    private static Field sessionField;
    private static Field gameField;
    private static Field phaseField;
    private static boolean failed;

    private ArcadeProbe() {
    }

    static boolean gameActive(Object screen) {
        if (failed || !(screen instanceof SleepScreen)) {
            return false;
        }
        try {
            if (sessionField == null) {
                sessionField = SleepScreen.class.getDeclaredField("session");
                sessionField.setAccessible(true);
            }
            Object session = sessionField.get(screen);
            if (session == null) {
                return false;
            }
            if (gameField == null) {
                Class<?> type = session.getClass();
                gameField = type.getDeclaredField("game");
                gameField.setAccessible(true);
                phaseField = type.getDeclaredField("phase");
                phaseField.setAccessible(true);
            }
            Object game = gameField.get(session);
            Object phase = phaseField.get(session);
            if (game == null || !(phase instanceof Enum<?> state)) {
                return false;
            }
            String name = state.name();
            return name.equals("RUNNING") || name.equals("PAUSED");
        } catch (ReflectiveOperationException | RuntimeException e) {
            failed = true; // el mod cambió por dentro: la pantalla simplemente queda apagada
            System.err.println("[" + GameboyAddon.MOD_ID + "] No se pudo leer el estado del arcade: " + e);
            return false;
        }
    }
}
