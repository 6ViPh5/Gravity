package com.gameboyaddon.network;

import com.gameboyaddon.GameboyAddon;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Cliente -> servidor.
 * playing:  la pantalla del arcade está abierta con la consola en la mano (pose de brazos).
 * screenOn: además hay un juego en curso o en pausa (la pantalla de la consola se ve encendida).
 */
public record GameboyStatePayload(boolean playing, boolean screenOn) implements CustomPacketPayload {
    public static final Identifier ID = GameboyAddon.id("state");
    public static final CustomPacketPayload.Type<GameboyStatePayload> TYPE = new CustomPacketPayload.Type<>(ID);
    public static final StreamCodec<FriendlyByteBuf, GameboyStatePayload> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeBoolean(p.playing());
                buf.writeBoolean(p.screenOn());
            },
            buf -> new GameboyStatePayload(buf.readBoolean(), buf.readBoolean()));

    @Override
    public CustomPacketPayload.Type<GameboyStatePayload> type() {
        return TYPE;
    }
}
