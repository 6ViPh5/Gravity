package com.gameboyaddon.network;

import com.gameboyaddon.GameboyAddon;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Cliente -> servidor: un sonido de la consola (instrumento 0-11 de note block + tono). */
public record GameboySoundPayload(int instrument, float pitch) implements CustomPacketPayload {
    public static final Identifier ID = GameboyAddon.id("sound");
    public static final CustomPacketPayload.Type<GameboySoundPayload> TYPE = new CustomPacketPayload.Type<>(ID);
    public static final StreamCodec<FriendlyByteBuf, GameboySoundPayload> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeVarInt(p.instrument());
                buf.writeFloat(p.pitch());
            },
            buf -> new GameboySoundPayload(buf.readVarInt(), buf.readFloat()));

    @Override
    public CustomPacketPayload.Type<GameboySoundPayload> type() {
        return TYPE;
    }
}
