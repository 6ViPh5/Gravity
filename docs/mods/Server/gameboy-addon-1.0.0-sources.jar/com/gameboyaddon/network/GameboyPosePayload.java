package com.gameboyaddon.network;

import com.gameboyaddon.GameboyAddon;
import java.util.UUID;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Servidor -> clientes cercanos: este jugador empieza/termina de usar la Gameboy. */
public record GameboyPosePayload(UUID player, boolean playing) implements CustomPacketPayload {
    public static final Identifier ID = GameboyAddon.id("pose");
    public static final CustomPacketPayload.Type<GameboyPosePayload> TYPE = new CustomPacketPayload.Type<>(ID);
    public static final StreamCodec<FriendlyByteBuf, GameboyPosePayload> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeUUID(p.player());
                buf.writeBoolean(p.playing());
            },
            buf -> new GameboyPosePayload(buf.readUUID(), buf.readBoolean()));

    @Override
    public CustomPacketPayload.Type<GameboyPosePayload> type() {
        return TYPE;
    }
}
