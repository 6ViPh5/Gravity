package com.gameboyaddon;

/** Ajustes simples (se cambian aquí y se recompila). */
public final class GameboyConfig {
    /** Ignora la tecla "Abrir arcade" del mod original. */
    public static final boolean DISABLE_OPEN_KEY = true;
    /** Quita también el botón de Arcade Dreams del menú de pausa. */
    public static final boolean DISABLE_PAUSE_BUTTON = false;
    /** Volumen con el que los demás oyen la consola (0.8 ≈ 12 bloques de alcance). */
    public static final float REMOTE_SOUND_VOLUME = 0.8F;
    /** Máximo de sonidos retransmitidos por segundo y jugador (anti-spam). */
    public static final int MAX_SOUNDS_PER_SECOND = 12;

    private GameboyConfig() {
    }
}
