package com.gameboyaddon.mixin;

import com.gameboyaddon.client.GameboyPoseState;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HumanoidModel.class)
public abstract class HumanoidModelMixin {
    /** Brazos hacia delante y juntos, como sosteniendo una consola con las dos manos. */
    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/HumanoidRenderState;)V", at = @At("TAIL"))
    private void gameboyaddon$gameboyPose(HumanoidRenderState state, CallbackInfo ci) {
        if (!((GameboyPoseState) (Object) state).gameboyaddon$isPosing()) {
            return;
        }
        HumanoidModel<?> self = (HumanoidModel<?>) (Object) this;
        float pitch = self.head.xRot * 0.4F;
        self.rightArm.xRot = -1.15F + pitch;
        self.rightArm.yRot = -0.55F;
        self.rightArm.zRot = 0.0F;
        self.leftArm.xRot = -1.15F + pitch;
        self.leftArm.yRot = 0.55F;
        self.leftArm.zRot = 0.0F;
    }
}
