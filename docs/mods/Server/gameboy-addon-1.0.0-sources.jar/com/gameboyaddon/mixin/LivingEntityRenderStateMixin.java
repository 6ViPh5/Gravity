package com.gameboyaddon.mixin;

import com.gameboyaddon.client.GameboyPoseState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(LivingEntityRenderState.class)
public abstract class LivingEntityRenderStateMixin implements GameboyPoseState {
    @Unique
    private boolean gameboyaddon$posing;

    @Override
    public void gameboyaddon$setPosing(boolean posing) {
        this.gameboyaddon$posing = posing;
    }

    @Override
    public boolean gameboyaddon$isPosing() {
        return this.gameboyaddon$posing;
    }
}
