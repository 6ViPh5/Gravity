package com.gameboyaddon.mixin;

import com.gameboyaddon.GameboyConfig;
import com.zeesea.client.ArcadeDreamsClient;
import com.zeesea.client.gui.ArcadeButton;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = ArcadeDreamsClient.class, remap = false)
public abstract class ArcadeDreamsClientMixin {
    /** La tecla "Abrir arcade" deja de abrir nada: se vacían sus pulsaciones y se devuelve false. */
    @Redirect(method = "onClientTick",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/KeyMapping;consumeClick()Z"))
    private static boolean gameboyaddon$ignoreOpenKey(KeyMapping key) {
        if (GameboyConfig.DISABLE_OPEN_KEY) {
            while (key.consumeClick()) {
                // descartar
            }
            return false;
        }
        return key.consumeClick();
    }

    /** Opcional: quita el botón del menú de pausa. */
    @Inject(method = "pauseMenuButton", at = @At("HEAD"), cancellable = true)
    private static void gameboyaddon$hidePauseButton(Screen screen, int height, boolean hasWidgets,
                                                     CallbackInfoReturnable<ArcadeButton> cir) {
        if (GameboyConfig.DISABLE_PAUSE_BUTTON) {
            cir.setReturnValue(null);
        }
    }
}
