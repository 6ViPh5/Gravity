package com.gameboyaddon.mixin;

import com.gameboyaddon.client.GameboyClient;
import com.zeesea.client.game.Sfx;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Todos los sonidos del arcade pasan por Sfx: aquí los copiamos al servidor para que los oigan los cercanos. */
@Mixin(value = Sfx.class, remap = false)
public abstract class SfxMixin {
    @Inject(method = "note", at = @At("HEAD"))
    private static void gameboyaddon$note(int instrument, int note, CallbackInfo ci) {
        float pitch = (float) Math.pow(2.0, (double) (note - 12) / 12.0);
        int inst = (instrument < 0 || instrument > 10) ? 11 : instrument;
        GameboyClient.sendSound(inst, pitch);
    }

    /** good() y bad() también pasan por blip(). */
    @Inject(method = "blip", at = @At("HEAD"))
    private static void gameboyaddon$blip(float pitch, CallbackInfo ci) {
        GameboyClient.sendSound(11, pitch);
    }
}
