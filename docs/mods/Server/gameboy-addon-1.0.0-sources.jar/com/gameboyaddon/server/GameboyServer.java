package com.gameboyaddon.server;

import com.gameboyaddon.GameboyAddon;
import com.gameboyaddon.GameboyConfig;
import com.gameboyaddon.network.GameboyPosePayload;
import com.gameboyaddon.network.GameboySoundPayload;
import com.gameboyaddon.network.GameboyStatePayload;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.EntityTrackingEvents;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;

/** Lógica del servidor: quién está jugando (pose de brazos) y retransmisión de sonidos a los cercanos. */
public final class GameboyServer {
    /** Flag 0 de custom_model_data = pantalla encendida (lo usa items/gameboy.json). */
    private static final CustomModelData LIT = new CustomModelData(List.of(), List.of(true), List.of(), List.of());
    private static final Set<UUID> PLAYING = new HashSet<>();
    private static final Set<UUID> LIT_PLAYERS = new HashSet<>();
    /** {tick de inicio de ventana, sonidos en la ventana} */
    private static final Map<UUID, int[]> SOUND_WINDOW = new HashMap<>();

    private GameboyServer() {
    }

    public static void init() {
        ServerPlayNetworking.registerGlobalReceiver(GameboyStatePayload.TYPE, (payload, context) -> {
            ServerPlayer player = context.player();
            boolean playing = payload.playing() && holdsGameboy(player);
            setPlaying(player, playing);
            setScreenLit(player, playing && payload.screenOn());
        });
        ServerPlayNetworking.registerGlobalReceiver(GameboySoundPayload.TYPE,
                (payload, context) -> onSound(context.player(), context.server().getTickCount(), payload));

        ServerTickEvents.END_SERVER_TICK.register(GameboyServer::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> forget(handler.player));
        // Por si quedó una consola "encendida" guardada (cierre brusco): se apaga al entrar.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> clearLit(handler.player));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            PLAYING.clear();
            LIT_PLAYERS.clear();
            SOUND_WINDOW.clear();
        });
        // Quien empieza a ver a un jugador que ya está jugando recibe su pose actual.
        EntityTrackingEvents.START_TRACKING.register((tracked, observer) -> {
            if (tracked instanceof ServerPlayer target && PLAYING.contains(target.getUUID())) {
                send(observer, new GameboyPosePayload(target.getUUID(), true));
            }
        });
    }

    public static boolean holdsGameboy(ServerPlayer player) {
        return player.getMainHandItem().is(GameboyAddon.GAMEBOY) || player.getOffhandItem().is(GameboyAddon.GAMEBOY);
    }

    private static ItemStack heldGameboy(ServerPlayer player) {
        if (player.getMainHandItem().is(GameboyAddon.GAMEBOY)) {
            return player.getMainHandItem();
        }
        if (player.getOffhandItem().is(GameboyAddon.GAMEBOY)) {
            return player.getOffhandItem();
        }
        return null;
    }

    /** Enciende/apaga la pantalla del modelo para todos los que ven al jugador (se sincroniza con el item). */
    private static void setScreenLit(ServerPlayer player, boolean lit) {
        if (lit) {
            ItemStack stack = heldGameboy(player);
            if (stack != null) {
                if (!LIT.equals(stack.get(DataComponents.CUSTOM_MODEL_DATA))) {
                    stack.set(DataComponents.CUSTOM_MODEL_DATA, LIT);
                }
                LIT_PLAYERS.add(player.getUUID());
            }
        } else if (LIT_PLAYERS.remove(player.getUUID())) {
            clearLit(player);
        }
    }

    private static void clearLit(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            unlight(inventory.getItem(i));
        }
        unlight(player.getOffhandItem());
    }

    private static void unlight(ItemStack stack) {
        if (stack.is(GameboyAddon.GAMEBOY) && stack.has(DataComponents.CUSTOM_MODEL_DATA)) {
            stack.remove(DataComponents.CUSTOM_MODEL_DATA);
        }
    }

    private static void setPlaying(ServerPlayer player, boolean on) {
        if (!on) {
            setScreenLit(player, false);
        }
        boolean changed = on ? PLAYING.add(player.getUUID()) : PLAYING.remove(player.getUUID());
        if (!on) {
            SOUND_WINDOW.remove(player.getUUID());
        }
        if (changed) {
            broadcast(player, on);
        }
    }

    private static void forget(ServerPlayer player) {
        setScreenLit(player, false);
        if (PLAYING.remove(player.getUUID())) {
            broadcast(player, false);
        }
        SOUND_WINDOW.remove(player.getUUID());
    }

    private static void broadcast(ServerPlayer player, boolean on) {
        GameboyPosePayload payload = new GameboyPosePayload(player.getUUID(), on);
        for (ServerPlayer observer : PlayerLookup.tracking(player)) {
            send(observer, payload);
        }
    }

    private static void send(ServerPlayer to, GameboyPosePayload payload) {
        if (ServerPlayNetworking.canSend(to, GameboyPosePayload.ID)) {
            ServerPlayNetworking.send(to, payload);
        }
    }

    /** Cada medio segundo comprueba que quien "juega" siga con la consola en la mano. */
    private static void tick(MinecraftServer server) {
        if (PLAYING.isEmpty() || server.getTickCount() % 10 != 0) {
            return;
        }
        for (UUID id : List.copyOf(PLAYING)) {
            ServerPlayer player = server.getPlayerList().getPlayer(id);
            if (player == null) {
                PLAYING.remove(id);
                LIT_PLAYERS.remove(id);
                SOUND_WINDOW.remove(id);
            } else if (!player.isAlive() || player.isSleeping() || !holdsGameboy(player)) {
                setPlaying(player, false);
            }
        }
    }

    private static void onSound(ServerPlayer player, int tick, GameboySoundPayload payload) {
        UUID id = player.getUUID();
        if (!PLAYING.contains(id)) {
            return;
        }
        int[] window = SOUND_WINDOW.computeIfAbsent(id, k -> new int[]{tick, 0});
        if (tick - window[0] >= 20) {
            window[0] = tick;
            window[1] = 0;
        }
        if (++window[1] > GameboyConfig.MAX_SOUNDS_PER_SECOND) {
            return;
        }
        float pitch = payload.pitch();
        if (Float.isNaN(pitch)) {
            return;
        }
        pitch = Math.max(0.5F, Math.min(2.0F, pitch));
        // El que juega ya lo oye en local: se excluye para no duplicarlo.
        player.level().playSound(player, player.getX(), player.getY(), player.getZ(),
                sound(payload.instrument()), SoundSource.PLAYERS, GameboyConfig.REMOTE_SOUND_VOLUME, pitch);
    }

    /** Mismos instrumentos y orden que Sfx.note() del mod original. */
    private static SoundEvent sound(int instrument) {
        return switch (instrument) {
            case 0 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 1 -> SoundEvents.NOTE_BLOCK_BASS.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 3 -> SoundEvents.NOTE_BLOCK_FLUTE.value();
            case 4 -> SoundEvents.NOTE_BLOCK_CHIME.value();
            case 5 -> SoundEvents.NOTE_BLOCK_GUITAR.value();
            case 6 -> SoundEvents.NOTE_BLOCK_XYLOPHONE.value();
            case 7 -> SoundEvents.NOTE_BLOCK_IRON_XYLOPHONE.value();
            case 8 -> SoundEvents.NOTE_BLOCK_COW_BELL.value();
            case 9 -> SoundEvents.NOTE_BLOCK_BANJO.value();
            case 10 -> SoundEvents.NOTE_BLOCK_PLING.value();
            default -> SoundEvents.NOTE_BLOCK_BIT.value();
        };
    }
}
