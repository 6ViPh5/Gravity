package com.gameboyaddon;

import com.gameboyaddon.item.GameboyItem;
import com.gameboyaddon.network.GameboyPosePayload;
import com.gameboyaddon.network.GameboySoundPayload;
import com.gameboyaddon.network.GameboyStatePayload;
import com.gameboyaddon.server.GameboyServer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public final class GameboyAddon implements ModInitializer {
    public static final String MOD_ID = "gameboyaddon";

    public static Item GAMEBOY;

    /** Lo rellena el cliente: abre la pantalla de Arcade Dreams. En el servidor no hace nada. */
    public static volatile Runnable clientUse = () -> {
    };

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id("gameboy"));
        GAMEBOY = Registry.register(BuiltInRegistries.ITEM, key,
                new GameboyItem(new Item.Properties().setId(key).stacksTo(1)));
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(output -> output.accept(GAMEBOY));

        // Los paquetes se registran en ambos lados.
        PayloadTypeRegistry.serverboundPlay().register(GameboyStatePayload.TYPE, GameboyStatePayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(GameboySoundPayload.TYPE, GameboySoundPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(GameboyPosePayload.TYPE, GameboyPosePayload.CODEC);

        GameboyServer.init();
    }
}
